package IPC::Cmd;

sub can_run
{
	die(@_);
}

1;
