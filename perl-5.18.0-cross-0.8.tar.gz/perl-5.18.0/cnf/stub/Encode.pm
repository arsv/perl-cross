package Encode;

sub encode
{
	return $_[1];
}

1;
